let name = "Nancy";
console.log(name);